package com.neosoft.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.neosoft.model.UserLogin;

public interface UserRepository  extends JpaRepository<UserLogin, String>{

	Optional<UserLogin> findByUserName(String userName);
	
	

}
