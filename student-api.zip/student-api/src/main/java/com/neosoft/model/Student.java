package com.neosoft.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="student")
public class Student {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
    @Column(name="first_name",nullable=false)
    private String firstName;
    @Column(name="last_name")
    private String lastName;
    @Column(name="mobile_number")
    private long mobileNumber;
    @Column(name="email_address")
    private String emailAddress;
    @OneToMany
    private Project project;
   
    
}
