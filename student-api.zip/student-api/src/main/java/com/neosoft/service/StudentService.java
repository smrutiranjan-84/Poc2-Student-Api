package com.neosoft.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neosoft.controller.StudentNotFoundException;
import com.neosoft.model.Student;

import com.neosoft.repository.StudentRepository;
@Service
public class StudentService  {
	@Autowired
	private StudentRepository repository;
	public List<Student> getAllStudents() {
		List<Student> students = new ArrayList<Student>();
		repository.findAll().forEach(user1 -> students.add(user1));
		return students;
	}

	public Student getStudentById(Long id) {
		return repository.findById(id).orElseThrow(
				StudentNotFoundException::new);
	}
	public void saveOrUpdate(Student students) {
		repository.save(students);
	}
}
