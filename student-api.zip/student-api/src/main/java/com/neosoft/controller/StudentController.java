package com.neosoft.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.neosoft.model.Student;
import com.neosoft.service.StudentService;
@RestController
public class StudentController {
	@Autowired
	StudentService studentService;
	//Get all students
	@GetMapping("/students")  
	private List<Student> getStudents()   
	{  
	return studentService.getAllStudents();  
	} 
	//Retrieve Student by student Id
	@GetMapping("/student/{studentId}")
	private Student getStudent(@PathVariable("studentId") Long studentId) {
		return studentService.getStudentById(studentId);
	}
	//Insert Students to Student Table
	@PostMapping("/students")
	private void saveUsers(@RequestBody Student student) {
		
		Student student1 = new Student();
	
			student1.setId(student.getId());
			student1.setFirstName(student.getFirstName());
			student1.setLastName(student.getLastName());
			student1.setMobileNumber(student.getMobileNumber());
			student1.setEmailAddress(student.getEmailAddress());
			student1.setProject(student.getProject());

			studentService.saveOrUpdate(student1);

		}

	}


